<h3>Subject : {{ $subject }}</h3>
<h4>Name : {{ $name }}</h4>
<h4>Phone : {{ $phone }}</h4>
<p>{!! $description  !!} </p>