
<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
        th,td{
            font-size: 14px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Date</th>
            <th>Reference ID</th>
            <th>Bonus Details</th>
            <th>Bonus Amount</th>
            <th>Past Balance</th>
            <th>Present Balance</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $bonus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td width="18%"><?php echo e(\Carbon\Carbon::parse($p->created_at)->format('d F Y h:i A')); ?></td>
                <td><?php echo e($p->under_reference); ?></td>
                <td><?php echo e($p->details); ?></td>
                <td><?php echo e($p->balance); ?> - <?php echo e($basic->currency); ?></td>
                <td><?php echo e($p->old_balance); ?> - <?php echo e($basic->currency); ?></td>
                <td><?php echo e($p->new_balance); ?> - <?php echo e($basic->currency); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>