<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Amount </th>
            <th>Deposit ID </th>
            <th>Plan Name</th>
            <th>Compound</th>
            <th>Made Time</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $repeat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($p->balance); ?> - <?php echo e($basic->currency); ?></td>
                <td><?php echo e($p->deposit->deposit_number); ?></td>
                <td><span class="aaaa"><?php echo e($p->deposit->plan->name); ?></span></td>
                <td>
                    <strong><span class="aaaa"><?php echo e($p->deposit->compound->name); ?></span></strong>
                </td>
                <td><strong><?php echo e(\Carbon\Carbon::parse($p->made_time)); ?></strong></td>
                <td>
                    <span class="label label-success"><i class="fa fa-check" aria-hidden="true"></i> Complete</span>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>