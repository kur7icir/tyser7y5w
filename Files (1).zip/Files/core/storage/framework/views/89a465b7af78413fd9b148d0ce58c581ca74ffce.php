<?php $__env->startSection('content'); ?>



    <!-- ========================== Inner Banner =================== -->
    <section class="inner_banner">
        <div class="container">
            <div class="banner-title">
                <h1><?php echo e($page_title); ?></h1>
                <span class="decor-equal"></span>
            </div>
        </div>
    </section>
    <!-- ========================== /Inner Banner =================== -->

    <!-- ======================= Breadcrumb ========================== -->
    <section class="breadcrumb_sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-6 col-sm-6 col-xs-5">
                    <h5><?php echo e($page_title); ?></h5>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-7">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="dot"></li>
                        <li><?php echo e($page_title); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- ======================= /Breadcrumb ========================== -->



    <!-- =========================== Contact container ================== -->
    <section class="contact_container">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 contact_text">
                    <div class="title_container">
                        <h4>Short Details About US</h4>
                        <span class="decor_default"></span>
                    </div>
                    <p style="text-align: justify"><?php echo $general->about_text; ?> </p>
                    <div class="meet_office">
                        <h4>Meet With Us:</h4>
                        <div style="width: 50%" class="address contact_information">
                            <h5>Address :</h5>
                            <p><?php echo e($general->address); ?></p>
                        </div> <!-- /address -->
                        <div class="mail contact_information">
                            <h5>Mail Us</h5>
                            <a href="mailto:<?php echo e($general->email); ?>"><?php echo e($general->email); ?></a>
                        </div> <!-- /mail -->
                        <div class="clear_fix"></div>
                    </div> <!-- /meet_office -->
                </div> <!-- /contact_text -->
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 lets_talk_to_us">
                    <div class="title_container">
                        <h4>Let’s Talk To Us</h4>
                        <span class="decor_default"></span>
                    </div>
                    <?php echo e(Form::open()); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <?php if(session()->has('message')): ?>
                                <div style="margin-bottom: 20px;margin-top: 20px;" class="alert alert-success alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo e(session()->get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                        <label>Your Name (Required)</label>
                        <div class="input-group">
                            <input type="text" name="name" placeholder="Name *" required class="form-control" aria-describedby="basic-addon2">
                            <span class="input-group-addon" id="basic-addon2"><i class="fa fa-user"></i></span>
                        </div>

                        <label>Email (Required)</label>
                        <div class="input-group">
                            <input type="email" name="email" placeholder="Email *" required class="form-control" aria-describedby="basic-addon3">
                            <span class="input-group-addon" id="basic-addon3"><i class="fa fa-envelope"></i></span>
                        </div>
                        <label>Subject (Required)</label>
                        <div class="input-group">
                            <input type="text" name="subject" placeholder="Subject *" required class="form-control" aria-describedby="basic-addon3">
                            <span class="input-group-addon" id="basic-addon3"><i class="fa fa-bars"></i></span>
                        </div>
                        <label>Tell Us More</label>
                        <div class="input-group input_group_textarea">
                            <textarea name="message" placeholder="Message *" required aria-describedby="basic-addon4"></textarea>
                            <span class="input-group-addon" id="basic-addon4"><i class="fa fa-comments"></i></span>
                        </div>
                        <button style="margin-bottom:40px;width: 100%" type="submit" class="button-main hvr-sweep-to-rightB submit_now">Send now</button>
                    <?php echo Form::close(); ?>

                </div> <!-- /lets_talk_to_us -->
            </div> <!-- /row -->
        </div> <!-- /container -->
    </section> <!-- /contact_container -->

    <!-- =========================== Contact container ================== -->


<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.font-end2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>