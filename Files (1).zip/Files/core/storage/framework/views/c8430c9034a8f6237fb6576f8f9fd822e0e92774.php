<?php $__env->startSection('title', 'Change password'); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <!-- BEGIN SAMPLE FORM PORTLET-->
            <div class="portlet light bordered">

                <div class="portlet-body form">
                    <form class="form-horizontal" action="<?php echo e(route('update-profile')); ?>" enctype="multipart/form-data" method="post" role="form">
                        <div class="form-body">

                            <?php echo csrf_field(); ?>



                            <div class="form-group">
                                <label class="col-md-3 control-label"><strong>Name</strong></label>

                                <div class="col-md-6">
                                    <input value="<?php echo e($admin->name); ?>" class="form-control input-lg" name="name"
                                           placeholder="Admin Name" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label"><strong>Admin Email</strong></label>

                                <div class="col-md-6">
                                    <input value="<?php echo e($admin->email); ?>" class="form-control input-lg" name="email"
                                           placeholder="Admin Email" type="email">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label"><strong>Admin Image</strong></label>

                                <div class="col-md-6">
                                    <img style="width: 25%;" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($admin->image); ?>" alt="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-3 control-label"><strong>Change Admin Image</strong></label>

                                <div class="col-md-6">
                                    <input class="form-control input-lg" name="image" type="file">
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-offset-3 col-md-6">
                                    <button type="submit" class="btn btn-blue btn-block"><i class="entypo-direction"></i> Update Profile</button>
                                </div>
                            </div>


                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!---ROW-->







<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>