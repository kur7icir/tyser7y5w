<?php $__env->startSection('content'); ?>

    <div class="col-md-12" >
        <a href="<?php echo e(route('partner-create')); ?>" style="margin-bottom: 20px;" class="btn btn-blue pull-right" >
            <i class="entypo-plus"></i> Add New Partner
        </a>
    </div>
    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Name</th>
            <th>Image</th>
            <th>Created Date</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td width="20%"><?php echo e($p->name); ?></td>
                <td>
                    <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($p->image); ?>" alt="">
                </td>
                <td width="10%"><?php echo e(date('d-F-Y',strtotime($p->created_at))); ?></td>
                <td width="13%">
                    <a href="<?php echo e(route('partner-edit',$p->id)); ?>" class="btn btn-info btn-sm">
                        <i class="fa fa-edit"></i>
                    </a>
                    <button type="button" class="btn btn-danger btn-sm delete_button"
                            data-toggle="modal" data-target="#DelModal"
                            data-id="<?php echo e($p->id); ?>">
                        <i class="fa fa-trash"></i>
                    </button>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete this.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('partner-delete')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>